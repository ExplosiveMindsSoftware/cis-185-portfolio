**Project Name: Comic Store**  
**CIS-185 Midterm Project**  
**Author: Jorge Cordero**  
**Date: 14 November 2025**  

